class Employee {
    private String id;
    private String fname;
    private String lname;
    
    Employee(String id, String fname, String lname){
        this.id = id;
        this.fname = fname;
        this.lname = lname;
    }

    public String getId(){
        return this.id;
    }
    public String getFname(){
        return this.fname;
    }
    public String getLname(){
        return this.lname;
    }

    public void display(){
        System.out.println("Employee id is " + id + " " + " and Employee name is " + fname + " " + lname );
    }
}

